<?php
$name = "Gourav Kashyap";
echo "Hello, $name!";
?>