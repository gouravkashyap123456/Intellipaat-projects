<?php
$name = "gourav kashyap assignment no 2";
echo $name;
?>
